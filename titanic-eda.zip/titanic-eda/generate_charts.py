import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid", palette="Set2")
plt.rcParams['figure.dpi'] = 110

df = pd.read_csv('data/titanic.csv')

# ---- Basic cleaning ----
df['Age'] = df['Age'].fillna(df['Age'].median())
df['Embarked'] = df['Embarked'].fillna(df['Embarked'].mode()[0])
df['Cabin_Known'] = df['Cabin'].notna().astype(int)
df['FamilySize'] = df['SibSp'] + df['Parch'] + 1

df.to_csv('data/titanic_cleaned.csv', index=False)

# 1. Survival counts
plt.figure(figsize=(5,4))
ax = sns.countplot(x='Survived', data=df)
ax.set_xticklabels(['Did not survive', 'Survived'])
ax.set_title('Survival Counts')
ax.set_xlabel('')
for p in ax.patches:
    ax.annotate(f'{int(p.get_height())}', (p.get_x()+p.get_width()/2, p.get_height()),
                ha='center', va='bottom')
plt.tight_layout()
plt.savefig('images/01_survival_counts.png')
plt.close()

# 2. Survival by sex
plt.figure(figsize=(5,4))
ax = sns.barplot(x='Sex', y='Survived', data=df, errorbar=None)
ax.set_title('Survival Rate by Sex')
ax.set_ylabel('Survival Rate')
plt.tight_layout()
plt.savefig('images/02_survival_by_sex.png')
plt.close()

# 3. Survival by class
plt.figure(figsize=(5,4))
ax = sns.barplot(x='Pclass', y='Survived', data=df, errorbar=None)
ax.set_title('Survival Rate by Passenger Class')
ax.set_ylabel('Survival Rate')
ax.set_xlabel('Passenger Class')
plt.tight_layout()
plt.savefig('images/03_survival_by_class.png')
plt.close()

# 4. Age distribution
plt.figure(figsize=(6,4))
ax = sns.histplot(df['Age'], bins=30, kde=True)
ax.set_title('Age Distribution of Passengers')
plt.tight_layout()
plt.savefig('images/04_age_distribution.png')
plt.close()

# 5. Age vs survival
plt.figure(figsize=(6,4))
ax = sns.histplot(data=df, x='Age', hue='Survived', bins=30, multiple='stack')
ax.set_title('Age Distribution by Survival')
plt.tight_layout()
plt.savefig('images/05_age_vs_survival.png')
plt.close()

# 6. Fare distribution
plt.figure(figsize=(6,4))
ax = sns.histplot(df['Fare'], bins=40, kde=True)
ax.set_title('Fare Distribution')
plt.tight_layout()
plt.savefig('images/06_fare_distribution.png')
plt.close()

# 7. Correlation heatmap
plt.figure(figsize=(6,5))
num_cols = ['Survived','Pclass','Age','SibSp','Parch','Fare','FamilySize','Cabin_Known']
corr = df[num_cols].corr()
sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0)
plt.title('Correlation Heatmap')
plt.tight_layout()
plt.savefig('images/07_correlation_heatmap.png')
plt.close()

# 8. Survival by embarkation port
plt.figure(figsize=(5,4))
ax = sns.barplot(x='Embarked', y='Survived', data=df, errorbar=None)
ax.set_title('Survival Rate by Port of Embarkation')
ax.set_ylabel('Survival Rate')
plt.tight_layout()
plt.savefig('images/08_survival_by_embarked.png')
plt.close()

# 9. Family size vs survival
plt.figure(figsize=(6,4))
ax = sns.barplot(x='FamilySize', y='Survived', data=df, errorbar=None)
ax.set_title('Survival Rate by Family Size')
ax.set_ylabel('Survival Rate')
plt.tight_layout()
plt.savefig('images/09_survival_by_familysize.png')
plt.close()

print("All charts generated.")
print(df.isna().sum())
print(df.describe(include='all').T[['count','mean','std','min','max']].head(12))
